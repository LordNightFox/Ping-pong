from pygame import *
import random
font.init()
window = display.set_mode((900,600))
color_fon = (149,145,140)
display.set_caption('Бадментон')
window.fill(color_fon)
game = True
clock = time.Clock()
FPS = 60
win = False
class GameSp(sprite.Sprite):
    def __init__(self, obgeckt_image, obgeckt_image_X, obgeckt_image_Y, obgeckt_x, obgeckt_y,speed_obgeckt):
        super().__init__()
        self.obgeckt_image_Y = obgeckt_image_Y
        self.obgeckt_image_X = obgeckt_image_X
        self.image = transform.scale(image.load(obgeckt_image), (obgeckt_image_X,obgeckt_image_Y))
        self.speed = speed_obgeckt
        self.rect = self.image.get_rect()
        self.rect.x = obgeckt_x
        self.rect.y = obgeckt_y

    def reset(self):
        window.blit(self.image,(self.rect.x,self.rect.y))
class Player(GameSp):
    def update1(self):
        keys_pressed = key.get_pressed()
        if keys_pressed[K_UP] and self.rect.y > 5:
            self.rect.y -= self.speed
        if keys_pressed[K_DOWN] and self.rect.y < 450:
            self.rect.y += self.speed
    def update2(self):
        keys_pressed = key.get_pressed()
        if keys_pressed[K_w] and self.rect.y > 5:
            self.rect.y -= self.speed
        if keys_pressed[K_s] and self.rect.y < 450:
            self.rect.y += self.speed


boll = Player('Ping_boll.png',100,100,350,250,10)
rocket1 =Player('rocket.png',100,200,0,100,7)
rocket2 =Player('rocket2.png',100,200,800,100,7)
while game:
    for e in event.get():
        if e.type == QUIT:
            game = False
    if not win:
        window.fill(color_fon)
        rocket1.reset()
        rocket1.update1()
        rocket2.reset()
        rocket2.update2()
    display.update()
    clock.tick(FPS)